// Trilium 0.102.2 表格选中统计纯净版
// 功能：Shift+鼠标选中表格单元格 → 弹窗常显统计结果，取消选中自动消失
(function() {
    // ====================== 【自定义配置区】 ======================
    const TRIGGER_KEY = 'shiftKey'; // 触发键：shiftKey / ctrlKey / altKey
    const TOAST_POSITION = 'bottom-right'; // 弹窗位置：bottom-right / top-right / bottom-left / top-left
    // =============================================================

    // 全局弹窗实例
    let toast = null;

    // 1. 创建/获取全局唯一弹窗
    function initToast() {
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'table-stats-toast';
            toast.style.cssText = `
                position: fixed; z-index: 99999; padding: 10px 16px;
                border-radius: 6px; background: #2c3e50; color: #fff;
                font-size: 14px; box-shadow: 0 2px 10px rgba(0,0,0,0.2);
                display: none; pointer-events: none;
            `;
            document.body.appendChild(toast);
        }
        return toast;
    }

    // 2. 设置弹窗在屏幕上的显示位置
    // 参数 position：从顶部【自定义配置区】传过来的位置字符串，比如 'bottom-right'
    function setToastPosition(position) {
        const t = initToast(); // 先获取全局唯一的弹窗实例
        
        // 【关键重置】把四个方向的位置都先设为 'auto'，清除之前的位置设置，避免冲突
        t.style.left = t.style.right = t.style.top = t.style.bottom = 'auto';
        
        // 根据传入的位置参数，设置弹窗距离屏幕边缘的具体像素值
        switch (position) {
            // 右上角：距离顶部 20px，距离右侧 20px
            // 【想调整位置】改 '20px' 这个数字即可，比如改成 '10px' 更靠边，'50px' 更靠中间
            case 'top-right': 
                t.style.top = '20px';    // 距离屏幕顶部的距离
                t.style.right = '20px';  // 距离屏幕右侧的距离
                break;
            
            // 左下角：距离底部 20px，距离左侧 20px
            case 'bottom-left': 
                t.style.bottom = '50px'; // 距离屏幕底部的距离
                t.style.left = '20px';   // 距离屏幕左侧的距离
                break;
            
            // 左上角：距离顶部 20px，距离左侧 20px
            case 'top-left': 
                t.style.top = '20px';    // 距离屏幕顶部的距离
                t.style.left = '20px';   // 距离屏幕左侧的距离
                break;
            
            // 默认位置（右下角）：如果上面的 case 都没匹配到，就用这个
            default: 
                t.style.bottom = '50px'; // 距离屏幕底部的距离
                t.style.right = '20px';  // 距离屏幕右侧的距离
        }
    }

    // 3. 显示统计结果
    function showStats(count, sum) {
        const t = initToast();
        setToastPosition(TOAST_POSITION);
        t.textContent = `选中：${count} 个单元格 | 数字总和：${sum.toFixed(2)}`;
        t.style.display = 'block';
    }

    // 4. 隐藏弹窗
    function hideStats() {
        if (toast) toast.style.display = 'none';
    }

    // 5. 核心：获取选中表格单元格的统计数据
    async function getTableStats() {
        try {
            const editor = await api.getActiveContextTextEditor();
            if (!editor) return { count: 0, sum: 0 };

            // 遍历模型选区，提取所有表格单元格
            const selection = editor.model.document.selection;
            const ranges = selection.getRanges();
            const cells = [];

            for (const range of ranges) {
                for (const item of range.getItems()) {
                    if (item.is('element', 'tableCell')) cells.push(item);
                }
            }

            // 计算数字总和
            let sum = 0;
            const mapper = editor.editing.mapper;
            const domConverter = editor.editing.view.domConverter;

            for (const modelCell of cells) {
                const viewCell = mapper.toViewElement(modelCell);
                const domCell = domConverter.viewToDom(viewCell, document);
                if (domCell) {
                    const numbers = domCell.textContent.trim().match(/[-+]?\d*\.?\d+/g) || [];
                    numbers.forEach(num => {
                        const val = parseFloat(num);
                        if (!isNaN(val)) sum += val;
                    });
                }
            }

            return { count: cells.length, sum: sum };

        } catch (err) {
            return { count: 0, sum: 0 };
        }
    }

    // 6. 监听鼠标松开：按住触发键选中表格，显示弹窗
    document.addEventListener('mouseup', async (e) => {
        if (!e[TRIGGER_KEY]) return;
        const { count, sum } = await getTableStats();
        if (count > 0) showStats(count, sum);
    }, true);

    // 7. 监听选区变化：取消选中自动隐藏弹窗
    document.addEventListener('selectionchange', async () => {
        const { count } = await getTableStats();
        if (count === 0) hideStats();
    });

    console.log('✅ 表格统计纯净版已加载');
})();